package com.example.cp06

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var peliculaAdapter: PeliculaAdapter
    private var peliculas = mutableListOf<Pelicula>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configurar la Toolbar
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        // Configurar el RecyclerView
        recyclerView = findViewById(R.id.recyclerViewPeliculas)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Cargar lista de películas
        cargarPeliculas()
    }

    private fun cargarPeliculas() {
        peliculas = mutableListOf(
            Pelicula(1, "La vida es bella", "Un padre judío-italiano...", R.drawable.la_vida_es_bella, 116, 1997, "Italia"),
            Pelicula(2, "El padrino", "El envejecido patriarca...", R.drawable.elpadrino, 175, 1972, "Estados Unidos"),
            Pelicula(3, "El caballero oscuro", "Cuando la amenaza conocida...", R.drawable.el_caballero_oscuro, 152, 2008, "Estados Unidos"),
            Pelicula(4, "Pulp Fiction", "La vida de dos sicarios...", R.drawable.pulpfiction, 154, 1994, "Estados Unidos"),
            Pelicula(5, "El Señor de los Anillos", "Gandalf y Aragorn lideran...", R.drawable.senhoranillos, 178, 2001, "Nueva Zelanda"),
            Pelicula(6, "Forrest Gump", "Los presidios de Forrest Gump...", R.drawable.forrestgump, 142, 1994, "Estados Unidos")
        )

        peliculaAdapter = PeliculaAdapter(peliculas)
        recyclerView.adapter = peliculaAdapter
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_recargar -> {
                recargarLista()
                true
            }
            R.id.menu_limpiar -> {
                limpiarLista()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun recargarLista() {
        cargarPeliculas()
        peliculaAdapter.notifyDataSetChanged()
        Toast.makeText(this, "Lista recargada", Toast.LENGTH_SHORT).show()
    }

    private fun limpiarLista() {
        peliculas.clear()
        peliculaAdapter.notifyDataSetChanged()
        Toast.makeText(this, "Lista vaciada", Toast.LENGTH_SHORT).show()
    }
}