package com.example.cp06

data class Pelicula(
    val id: Int,
    val titulo: String,
    val descripcion: String,
    val imagen: Int,
    val duracion: Int,
    val anio: Int,
    val pais: String
)
