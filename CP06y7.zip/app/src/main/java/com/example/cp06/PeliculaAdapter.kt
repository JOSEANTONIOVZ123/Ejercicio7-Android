package com.example.cp06

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class PeliculaAdapter(private val peliculas: List<Pelicula>) :
    RecyclerView.Adapter<PeliculaAdapter.PeliculaViewHolder>() {

    inner class PeliculaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titulo: TextView = itemView.findViewById(R.id.textViewTitulo)
        val imagen: ImageView = itemView.findViewById(R.id.imageViewPelicula)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PeliculaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pelicula, parent, false)
        return PeliculaViewHolder(view)
    }

    override fun onBindViewHolder(holder: PeliculaViewHolder, position: Int) {
        val pelicula = peliculas[position]
        holder.titulo.text = pelicula.titulo
        holder.imagen.setImageResource(pelicula.imagen)

        holder.itemView.setOnClickListener {
            Toast.makeText(
                holder.itemView.context,
                "Duración: ${pelicula.duracion} minutos – Año: ${pelicula.anio}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun getItemCount() = peliculas.size
}
